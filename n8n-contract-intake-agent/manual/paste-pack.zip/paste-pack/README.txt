PASTE-PACK — файлы для копирования и вставки при ручной сборке воркфлоу n8n
(пошаговая инструкция — файл «Инструкция_сборка_воркфлоу_n8n_40_узлов.docx»)

КАК ПОЛЬЗОВАТЬСЯ
1. Откройте нужный файл в Блокноте (двойной щелчок).
2. Ctrl+A, затем Ctrl+C — всё содержимое файла скопировано.
3. В n8n щёлкните в нужное поле и нажмите Ctrl+V. Куда именно — написано в инструкции для каждого узла.
Файлы в кодировке UTF-8, переносы строк — Unix (LF). Не редактируйте их перед вставкой. Если вместо русских букв видны «кракозябры», откройте файл в другом редакторе (VS Code, Notepad++) или выберите в Блокноте кодировку UTF-8.

ПАПКИ
  code/        код 15 узлов Code (поле JavaScript)
  prompts/     system-промпты и user-выражения узлов OpenAI, JSON-схемы (поле Schema)
  texts/       тексты сообщений бота (узлы 7, 8, 40)
  expressions/ длинные выражения (узлы 5, 14, 37, 38, 39)
  names.txt    имена всех 40 узлов — копируйте оттуда при переименовании (в A1, A3, A4, A5, A7, A8 буква латинская!)
  datatable_columns.txt  колонки таблицы contract_requests
  reference/   готовый воркфлоу (Import from file…) для сверки со своей сборкой

СООТВЕТСТВИЕ ФАЙЛ → УЗЕЛ → ПОЛЕ
  code/02_normalize_input.js                       узел  2 «Нормализация входа» — поле JavaScript
  expressions/05_edit_text_expression.txt          узел  5 «Убрать кнопки» — поле Text
  texts/07_welcome_text.txt                        узел  7 «Приветствие и справка» — поле Text — сначала переключить поле в режим Expression, потом вставить
  texts/08_unsupported_text.txt                    узел  8 «Формат не поддерживается» — поле Text (обычный режим)
  code/10_dialog_state.js                          узел 10 «Состояние диалога» — поле JavaScript
  code/11_reference_data.js                        узел 11 «Справочники и регламент» — поле JavaScript
  expressions/14_llm_prompt_expression.txt         узел 14 «Подготовка запроса к LLM» — Fields to Set → value
  prompts/15_schema_contract_card.json             узел 15 «A1 LLM: извлечение карточки» — Options → Output Format → Schema
  prompts/15_system_prompt.txt                     узел 15 «A1 LLM: извлечение карточки» — Messages → первое сообщение (Role = System) → Prompt
  prompts/16_system_prompt.txt                     узел 16 «A1 LLM (запасной): JSON-режим» — Messages → первое сообщение (Role = System) → Prompt
  code/17_merge_card.js                            узел 17 «Слияние с карточкой» — поле JavaScript
  code/19_quick_actions.js                         узел 19 «Быстрые действия» — поле JavaScript
  code/20_a1_directory.js                          узел 20 «A1 Справочник контрагента» — поле JavaScript
  code/21_a3_check.js                              узел 21 «A3 Проверка комплектности» — поле JavaScript
  code/22_a7_route.js                              узел 22 «A7 Подбор маршрута» — поле JavaScript
  code/24_a8_register.js                           узел 24 «A8 Регистрация заявки» — поле JavaScript
  code/25_env_confirm.js                           узел 25 «Конверт: карточка на подтверждение» — поле JavaScript
  code/26_env_escalate.js                          узел 26 «Конверт: эскалация» — поле JavaScript
  prompts/27_schema_clarification_questions.json   узел 27 «A5 LLM: уточняющие вопросы» — Options → Output Format → Schema
  prompts/27_system_prompt.txt                     узел 27 «A5 LLM: уточняющие вопросы» — Messages → первое сообщение (Role = System) → Prompt
  prompts/27_user_expression.txt                   узел 27 «A5 LLM: уточняющие вопросы» — Messages → второе сообщение (Role = User) → Prompt
  code/28_env_questions.js                         узел 28 «Конверт: вопросы» — поле JavaScript
  code/29_rag_search.js                            узел 29 «Поиск по регламенту (RAG)» — поле JavaScript
  prompts/30_system_prompt.txt                     узел 30 «Ответ по регламенту (LLM)» — Messages → первое сообщение (Role = System) → Prompt
  prompts/30_user_expression.txt                   узел 30 «Ответ по регламенту (LLM)» — Messages → второе сообщение (Role = User) → Prompt
  code/31_env_answer.js                            узел 31 «Конверт: ответ по регламенту» — поле JavaScript
  code/34_db_row.js                                узел 34 «Запись для БД» — поле JavaScript
  expressions/37_38_send_text_expression.txt       узел 37 «Отправить с кнопками» — поле Text
  expressions/39_plain_text_expression.txt         узел 39 «Отправить без форматирования» — поле Text
  texts/40_error_text.txt                          узел 40 «Сообщение об ошибке» — поле Text (обычный режим)
